# Job Application Tracker

A portfolio-ready desktop job application tracker built with **Python + Tkinter + SQLite**.

## Features
- Add, edit and delete applications
- Status tracking: Applied, Interview, Rejected, Selected
- Search across company, position, location and notes
- Status filtering and sorting
- Dashboard counters: Total, Active, Applied, Interview, Selected, Rejected
- Persistent local SQLite database
- CSV export of the current filtered/sorted view
- URL and date validation
- Confirmation before destructive deletion
- Clean modular structure

## Run

1. Install Python 3.10+.
2. Make sure Tkinter is installed.
3. Open this folder in VS Code.
4. Run:

```bash
python app.py
```

No `pip install` is required.

## Test

```bash
python -m unittest discover -s tests -p "test_*.py"
```

## Structure

```text
job-application-tracker/
├── app.py              # GUI and application flow
├── database.py         # SQLite CRUD and statistics
├── validation.py       # Input validation
├── exporter.py         # CSV export
├── requirements.txt
├── README.md
├── .gitignore
├── tests/
│   └── test_project.py
├── data/               # runtime database (ignored by Git)
└── exports/            # generated CSV files (ignored by Git)
```

## GitHub

The generated database and exports are intentionally ignored. Commit source code, tests, README and `.gitignore`.
