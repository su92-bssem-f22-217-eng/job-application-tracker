from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import date
import webbrowser
from database import init_db, add_application, update_application, delete_application, list_applications, get_application, stats
from validation import validate, STATUSES
from exporter import export_csv

BG='#f5f7fb'; CARD='#ffffff'; TEXT='#172033'; MUTED='#667085'; ACCENT='#2563eb'

class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title('Job Application Tracker'); self.geometry('1180x760'); self.minsize(1000,680); self.configure(bg=BG)
        self.selected_id=None; self.vars={k:tk.StringVar() for k in ('company','position','location','application_date','status','url','notes')}
        self.search=tk.StringVar(); self.filter=tk.StringVar(value='All'); self.sort=tk.StringVar(value='date_desc')
        self.build(); self.clear_form(); self.refresh()

    def style(self):
        s=ttk.Style(self); s.theme_use('clam'); s.configure('TFrame',background=BG); s.configure('Card.TFrame',background=CARD)
        s.configure('TLabel',background=BG,foreground=TEXT,font=('Segoe UI',10)); s.configure('Title.TLabel',background=BG,foreground=TEXT,font=('Segoe UI',23,'bold'))
        s.configure('Muted.TLabel',background=BG,foreground=MUTED,font=('Segoe UI',9)); s.configure('Card.TLabel',background=CARD,foreground=TEXT)
        s.configure('TButton',font=('Segoe UI',10),padding=(12,7)); s.configure('Accent.TButton',background=ACCENT,foreground='white'); s.map('Accent.TButton',background=[('active','#1d4ed8')])
        s.configure('Treeview',rowheight=31,font=('Segoe UI',9),background='white',fieldbackground='white',foreground=TEXT); s.configure('Treeview.Heading',font=('Segoe UI',9,'bold'))

    def build(self):
        self.style(); outer=ttk.Frame(self,padding=18); outer.pack(fill='both',expand=True)
        top=ttk.Frame(outer); top.pack(fill='x'); ttk.Label(top,text='Job Application Tracker',style='Title.TLabel').pack(side='left'); ttk.Button(top,text='Export CSV',command=self.export).pack(side='right')
        ttk.Label(outer,text='Track applications, interviews, outcomes and notes in one place.',style='Muted.TLabel').pack(anchor='w',pady=(2,14))
        self.stats_frame=ttk.Frame(outer); self.stats_frame.pack(fill='x',pady=(0,12)); self.stat_labels={}
        for key in ('Total','Applied','Interview','Selected','Rejected','Active'):
            f=ttk.Frame(self.stats_frame,style='Card.TFrame',padding=12); f.pack(side='left',fill='x',expand=True,padx=3); ttk.Label(f,text=key,style='Card.TLabel').pack(anchor='w'); l=ttk.Label(f,text='0',style='Card.TLabel',font=('Segoe UI',17,'bold')); l.pack(anchor='w',pady=(2,0)); self.stat_labels[key]=l
        form=ttk.LabelFrame(outer,text='Application Details',padding=12); form.pack(fill='x',pady=(0,12))
        fields=[('Company','company'),('Position','position'),('Location','location'),('Application Date','application_date'),('URL','url')]
        for i,(label,key) in enumerate(fields):
            r=i//2; c=(i%2)*2; ttk.Label(form,text=label).grid(row=r,column=c,sticky='w',padx=(0,7),pady=5); ttk.Entry(form,textvariable=self.vars[key]).grid(row=r,column=c+1,sticky='ew',padx=(0,18),pady=5)
        ttk.Label(form,text='Status').grid(row=2,column=0,sticky='w',pady=5); ttk.Combobox(form,textvariable=self.vars['status'],values=STATUSES,state='readonly').grid(row=2,column=1,sticky='ew',padx=(0,18),pady=5)
        ttk.Label(form,text='Notes').grid(row=2,column=2,sticky='nw',pady=5); ttk.Entry(form,textvariable=self.vars['notes']).grid(row=2,column=3,sticky='ew',padx=(0,18),pady=5)
        form.columnconfigure(1,weight=1); form.columnconfigure(3,weight=1)
        buttons=ttk.Frame(form); buttons.grid(row=3,column=0,columnspan=4,sticky='w',pady=(7,0)); ttk.Button(buttons,text='Add Application',style='Accent.TButton',command=self.add).pack(side='left',padx=(0,7)); ttk.Button(buttons,text='Update Selected',command=self.update).pack(side='left',padx=7); ttk.Button(buttons,text='Delete Selected',command=self.delete).pack(side='left',padx=7); ttk.Button(buttons,text='Clear',command=self.clear_form).pack(side='left',padx=7)
        filters=ttk.Frame(outer); filters.pack(fill='x',pady=(0,8)); ttk.Label(filters,text='Search:').pack(side='left'); e=ttk.Entry(filters,textvariable=self.search,width=32); e.pack(side='left',padx=6); e.bind('<KeyRelease>',lambda _:self.refresh()); ttk.Label(filters,text='Status:').pack(side='left',padx=(14,5)); cb=ttk.Combobox(filters,textvariable=self.filter,values=('All',)+STATUSES,state='readonly',width=13); cb.pack(side='left'); cb.bind('<<ComboboxSelected>>',lambda _:self.refresh()); ttk.Label(filters,text='Sort:').pack(side='left',padx=(14,5)); sb=ttk.Combobox(filters,textvariable=self.sort,values=('date_desc','date_asc','company','status'),state='readonly',width=13); sb.pack(side='left'); sb.bind('<<ComboboxSelected>>',lambda _:self.refresh())
        frame=ttk.Frame(outer); frame.pack(fill='both',expand=True); cols=('id','company','position','location','application_date','status','url','notes'); self.tree=ttk.Treeview(frame,columns=cols,show='headings',selectmode='browse'); names={'id':'ID','company':'Company','position':'Position','location':'Location','application_date':'Applied','status':'Status','url':'URL','notes':'Notes'}; widths={'id':45,'company':140,'position':170,'location':120,'application_date':95,'status':90,'url':220,'notes':180}
        for c in cols: self.tree.heading(c,text=names[c]); self.tree.column(c,width=widths[c],anchor='w')
        ys=ttk.Scrollbar(frame,orient='vertical',command=self.tree.yview); xs=ttk.Scrollbar(frame,orient='horizontal',command=self.tree.xview); self.tree.configure(yscrollcommand=ys.set,xscrollcommand=xs.set); self.tree.grid(row=0,column=0,sticky='nsew'); ys.grid(row=0,column=1,sticky='ns'); xs.grid(row=1,column=0,sticky='ew'); frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1); self.tree.bind('<<TreeviewSelect>>',self.select)
        self.tree.tag_configure('Rejected',foreground='#b42318'); self.tree.tag_configure('Selected',foreground='#067647')

    def data(self): return {k:self.vars[k].get().strip() for k in self.vars}
    def clear_form(self): self.selected_id=None; [v.set('') for v in self.vars.values()]; self.vars['application_date'].set(date.today().isoformat()); self.vars['status'].set('Applied'); self.tree.selection_remove(self.tree.selection()) if hasattr(self,'tree') else None
    def add(self):
        d=self.data(); ok,msg=validate(d)
        if not ok: messagebox.showerror('Validation Error',msg); return
        add_application(d); self.clear_form(); self.refresh(); messagebox.showinfo('Saved','Application added successfully.')
    def update(self):
        if not self.selected_id: messagebox.showwarning('Select Application','Select an application first.'); return
        d=self.data(); ok,msg=validate(d)
        if not ok: messagebox.showerror('Validation Error',msg); return
        update_application(self.selected_id,d); self.clear_form(); self.refresh(); messagebox.showinfo('Updated','Application updated successfully.')
    def delete(self):
        if not self.selected_id: messagebox.showwarning('Select Application','Select an application first.'); return
        if messagebox.askyesno('Confirm Delete','Delete the selected application?'): delete_application(self.selected_id); self.clear_form(); self.refresh()
    def select(self,_=None):
        s=self.tree.selection()
        if not s:return
        r=self.tree.item(s[0],'values'); self.selected_id=int(r[0]); row=get_application(self.selected_id)
        for k in self.vars: self.vars[k].set(row[k] or '')
    def refresh(self):
        if not hasattr(self,'tree'): return
        for i in self.tree.get_children(): self.tree.delete(i)
        for r in list_applications(self.search.get().strip(),self.filter.get(),self.sort.get()): self.tree.insert('', 'end', values=tuple(r[k] for k in ('id','company','position','location','application_date','status','url','notes')),tags=(r['status'],))
        for k,v in stats().items(): self.stat_labels[k].config(text=str(v))
    def export(self):
        rows=list_applications(self.search.get().strip(),self.filter.get(),self.sort.get())
        if not rows: messagebox.showwarning('Nothing to Export','There are no matching applications.'); return
        dest=filedialog.askdirectory(title='Choose export folder')
        if dest:
            p=export_csv(rows,dest); messagebox.showinfo('Export Complete',f'CSV saved to:\n{p}')

if __name__=='__main__':
    init_db(); App().mainloop()
