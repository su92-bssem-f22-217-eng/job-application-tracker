from __future__ import annotations
import sqlite3
from pathlib import Path
from contextlib import contextmanager

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "data" / "job_tracker.db"
DB_PATH.parent.mkdir(exist_ok=True)

SCHEMA = '''
CREATE TABLE IF NOT EXISTS applications (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 company TEXT NOT NULL,
 position TEXT NOT NULL,
 location TEXT DEFAULT '',
 application_date TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('Applied','Interview','Rejected','Selected')),
 url TEXT DEFAULT '',
 notes TEXT DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_app_status ON applications(status);
CREATE INDEX IF NOT EXISTS idx_app_date ON applications(application_date);
'''

@contextmanager
def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def init_db():
    with connect() as conn:
        conn.executescript(SCHEMA)

def add_application(data: dict) -> int:
    with connect() as c:
        cur = c.execute('''INSERT INTO applications
            (company,position,location,application_date,status,url,notes)
            VALUES (?,?,?,?,?,?,?)''', tuple(data[k] for k in ('company','position','location','application_date','status','url','notes')))
        return int(cur.lastrowid)

def update_application(app_id: int, data: dict):
    with connect() as c:
        c.execute('''UPDATE applications SET company=?,position=?,location=?,application_date=?,status=?,url=?,notes=?,updated_at=CURRENT_TIMESTAMP WHERE id=?''',
                  tuple(data[k] for k in ('company','position','location','application_date','status','url','notes')) + (app_id,))

def delete_application(app_id: int):
    with connect() as c: c.execute('DELETE FROM applications WHERE id=?',(app_id,))

def get_application(app_id: int):
    with connect() as c: return c.execute('SELECT * FROM applications WHERE id=?',(app_id,)).fetchone()

def list_applications(search='', status='All', sort='date_desc'):
    sql='SELECT * FROM applications WHERE 1=1'; params=[]
    if search:
        sql += ' AND (company LIKE ? OR position LIKE ? OR location LIKE ? OR notes LIKE ?)'; q=f'%{search}%'; params += [q,q,q,q]
    if status != 'All': sql += ' AND status=?'; params.append(status)
    order={'date_desc':'application_date DESC, id DESC','date_asc':'application_date ASC, id ASC','company':'company COLLATE NOCASE ASC, id DESC','status':'status ASC, application_date DESC'}.get(sort,'application_date DESC, id DESC')
    sql += ' ORDER BY ' + order
    with connect() as c: return c.execute(sql,params).fetchall()

def stats():
    with connect() as c:
        total=c.execute('SELECT COUNT(*) FROM applications').fetchone()[0]
        out={'Total':total}
        for s in ('Applied','Interview','Rejected','Selected'):
            out[s]=c.execute('SELECT COUNT(*) FROM applications WHERE status=?',(s,)).fetchone()[0]
        out['Active']=out['Applied']+out['Interview']
        return out
