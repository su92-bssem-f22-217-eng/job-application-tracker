import csv
from pathlib import Path
from datetime import datetime

HEADERS=['ID','Company','Position','Location','Application Date','Status','URL','Notes']

def export_csv(rows, directory):
    Path(directory).mkdir(parents=True,exist_ok=True)
    path=Path(directory)/f'job_applications_{datetime.now():%Y%m%d_%H%M%S}.csv'
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f); w.writerow(HEADERS)
        for r in rows: w.writerow([r['id'],r['company'],r['position'],r['location'],r['application_date'],r['status'],r['url'],r['notes']])
    return path
