import tempfile
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parents[1]))
import database, validation

def test_validation():
    d={'company':'Acme','position':'Python Developer','location':'Lahore','application_date':'2026-10-01','status':'Applied','url':'https://example.com','notes':''}
    assert validation.validate(d)[0]
    d['company']=''; assert not validation.validate(d)[0]

def test_crud(tmp_path, monkeypatch):
    monkeypatch.setattr(database,'DB_PATH',tmp_path/'test.db'); database.init_db()
    d={'company':'Acme','position':'Python Developer','location':'Lahore','application_date':'2026-10-01','status':'Applied','url':'https://example.com','notes':'test'}
    i=database.add_application(d); assert database.get_application(i)['company']=='Acme'
    d['status']='Interview'; database.update_application(i,d); assert database.get_application(i)['status']=='Interview'
    assert database.stats()['Interview']==1
    database.delete_application(i); assert database.stats()['Total']==0
