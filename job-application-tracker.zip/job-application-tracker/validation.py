from datetime import date, datetime
from urllib.parse import urlparse
STATUSES=('Applied','Interview','Rejected','Selected')

def validate(data):
    if not data['company'].strip(): return False,'Company name is required.'
    if not data['position'].strip(): return False,'Position is required.'
    try: datetime.strptime(data['application_date'],'%Y-%m-%d')
    except ValueError: return False,'Date must be in YYYY-MM-DD format.'
    if data['application_date'] > date.today().isoformat(): return False,'Application date cannot be in the future.'
    if data['status'] not in STATUSES: return False,'Choose a valid status.'
    url=data['url'].strip()
    if url:
        p=urlparse(url)
        if p.scheme not in ('http','https') or not p.netloc: return False,'URL must start with http:// or https://.'
    return True,''
